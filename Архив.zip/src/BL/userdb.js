export const accounts = [
    { username: 'user', password: 'password',name:'User' },
    { username: 'Damir', password: 'lolzik2281337',name:'Damir' },
    // добавьте еще учетные данные при необходимости
  ];
  
